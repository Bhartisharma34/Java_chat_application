document.addEventListener('DOMContentLoaded', function () {
    const messageForm = document.getElementById('message-form');
    const messageInput = document.getElementById('message-input');
    const messageContainer = document.getElementById('message-container');

    // Function to add a new message to the message container
    function addMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.innerText = message;
        messageContainer.appendChild(messageElement);
    }

    // Event listener for message form submission
    messageForm.addEventListener('submit', function (event) {
        event.preventDefault(); // Prevent default form submission

        const message = messageInput.value.trim(); // Get message text
        if (message !== '') {
            addMessage('You: ' + message); // Add message to container
            messageInput.value = ''; // Clear message input
            // Here you can send the message to the server or perform any other action
        }
    });
});
