// SendMessageServlet.java
package com.mycompany.javachatapp.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mycompany.javachatapp.dao.MessageDAO;
import com.mycompany.javachatapp.Message;

@WebServlet("/send-message")
public class SendMessageServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve sender and receiver IDs and message content from the request
        int senderId = Integer.parseInt(request.getParameter("senderId"));
        int receiverId = Integer.parseInt(request.getParameter("receiverId"));
        String messageContent = request.getParameter("messageContent");

        // Create a new Message object
        Message message = new Message();
        message.setSenderId(senderId);
        message.setReceiverId(receiverId);
        message.setMessageContent(messageContent);

        // Instantiate MessageDAO
        MessageDAO messageDAO = new MessageDAO();

        // Attempt to send the message
        boolean sendSuccess = messageDAO.sendMessage(message);

        if (sendSuccess) {
            // Message sent successfully, redirect to chat page or show confirmation message
            response.sendRedirect("chat.jsp");
        } else {
            // Message sending failed, handle error (redirect or display error message)
            response.sendRedirect("error.jsp");
        }
    }
}
