package com.mycompany.javachatapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mycompany.javachatapp.Message;
import com.mycompany.javachatapp.util.DatabaseUtil;

public class MessageDAO {

    public boolean sendMessage(Message message) {
        String query = "INSERT INTO messages (sender_id, receiver_id, message_content) VALUES (?, ?, ?)";
        try (Connection con = DatabaseUtil.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, message.getSenderId());
            pst.setInt(2, message.getReceiverId());
            pst.setString(3, message.getMessageContent());
            int result = pst.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false in case of an error
        }
    }

    public List<Message> getMessages(int senderId, int receiverId) {
        List<Message> messages = new ArrayList<>();
        String query = "SELECT * FROM messages WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?) ORDER BY timestamp";
        try (Connection con = DatabaseUtil.getConnection();
             PreparedStatement pst = con.prepareStatement(query)) {
            pst.setInt(1, senderId);
            pst.setInt(2, receiverId);
            pst.setInt(3, receiverId); // corrected index for receiverId
            pst.setInt(4, senderId); // corrected index for senderId
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    Message message = new Message();
                    message.setId(rs.getInt("id"));
                    message.setSenderId(rs.getInt("sender_id"));
                    message.setReceiverId(rs.getInt("receiver_id"));
                    message.setMessageContent(rs.getString("message_content"));
                    message.setTimestamp(rs.getTimestamp("timestamp"));
                    messages.add(message);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return messages;
    }
}
