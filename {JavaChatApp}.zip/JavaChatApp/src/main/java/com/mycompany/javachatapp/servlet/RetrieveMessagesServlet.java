// RetrieveMessagesServlet.java
package com.mycompany.javachatapp.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mycompany.javachatapp.dao.MessageDAO;
import com.mycompany.javachatapp.Message;
import java.util.List;

@WebServlet("/retrieve-messages")
public class RetrieveMessagesServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve sender and receiver IDs from the request
        int senderId = Integer.parseInt(request.getParameter("senderId"));
        int receiverId = Integer.parseInt(request.getParameter("receiverId"));

        // Instantiate MessageDAO
        MessageDAO messageDAO = new MessageDAO();

        // Retrieve messages between the sender and receiver
        List<Message> messages = messageDAO.getMessages(senderId, receiverId);

        // Store retrieved messages in request attribute
        request.setAttribute("messages", messages);

        // Forward the request to a JSP page to display the messages
        request.getRequestDispatcher("messages.jsp").forward(request, response);
    }
}
