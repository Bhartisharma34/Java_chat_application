// RegistrationServlet.java
package com.mycompany.javachatapp.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mycompany.javachatapp.dao.UserDAO;
import com.mycompany.javachatapp.User;

@WebServlet("/register")
public class RegistrationServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve user input from registration form
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Create a new User object
        User newUser = new User(username, password);

        // Instantiate UserDAO
        UserDAO userDAO = new UserDAO();

        // Attempt to register the user
        boolean registrationSuccess = userDAO.registerUser(newUser);

        if (registrationSuccess) {
            // Registration successful, redirect to login page
            response.sendRedirect("login.jsp");
        } else {
            // Registration failed, redirect back to registration page with error message
            response.sendRedirect("register.jsp?error=1");
        }
    }
}
